
public class Multithreading {
	
	/**
	 * Out of the box, the Thread object does nothing
	 * We need to provide a class that Overrides the "Runnable" interface.		
	 * Starts new thread. This will invoke t1's "run" method. 
	 * When the thread is done, the "run" method will return.
	 * Invoking the thread multiple times causes IllegalThreadStateException 
	 */
	public static void basicMultithreadingExtendingThreadClass() {
		//Instantiate our threads:
		TestThread t1 = new TestThread("t1", 1);
		TestThread t2 = new TestThread("t2", 2);
		
		//Start threads:
		t1.start();
		t2.start();
	}
	
	/**
	 * We can also do multithreading by implementing the Runnable interface.
	 * This is better because Java doesn't support multiple inheritence.
	 * This means that we can only extend Thread class and can't extend other class.
	 * A thread object can then execute whatever we specify in the "run" method.
	 */
	public static void basicMultithreadingImplementingRunnableInterface() {
		//Instantiate our threads:
		Runnable t3 = new TestRunnable("t3", 3);
		Runnable t4 = new TestRunnable("t4", 4);
		
		//Start threads:
		new Thread(t3).start();
		new Thread(t4).start();
	}
	
	//TODO: Callables
	//TODO: FutureTasks
	
	public static void main(String args[]) {
		
		basicMultithreadingExtendingThreadClass(); //Using a class that extends Thread class
		
		basicMultithreadingImplementingRunnableInterface(); //Using a class that implements Runnable interface	
		
	}
}
